const electron = require('electron');
const path = require('path');
const os = require('os');
const app = electron.app;
const Menu = electron.Menu;
const Tray = electron.Tray;
var fs = require('fs');
const assetsDirectory = path.join(__dirname, 'assets');
var appIcon = null;
var file = path.join(os.homedir(), '/times.csv');

app.on('ready', function() {
  fs.appendFileSync(
    file,
    'event, timestamp\r\n' + 'started,' + Date.now().toString() + '\r\n'
  );
  var stopped = false;
  appIcon = new Tray(path.join(assetsDirectory, 'play.png'));
  appIcon.setTitle('Recording');

  appIcon.on('click', event => {
    if (stopped) {
      appIcon.setTitle('Recording');
      appIcon.setImage(path.join(assetsDirectory, 'play.png'));
      fs.appendFileSync(file, 'started,' + Date.now() + '\r\n');
    } else {
      appIcon.setTitle('Stopped');
      appIcon.setImage(path.join(assetsDirectory, 'pause.png'));
      fs.appendFileSync(file, 'stopped,' + Date.now() + '\r\n');
    }
    stopped = !stopped;
  });

  const contextMenu = Menu.buildFromTemplate([
    {
      label: 'Close',
      click() {
        app.quit();
      }
    }
  ]);
  appIcon.setToolTip('Experiment in progress');
  appIcon.setContextMenu(contextMenu);
});
